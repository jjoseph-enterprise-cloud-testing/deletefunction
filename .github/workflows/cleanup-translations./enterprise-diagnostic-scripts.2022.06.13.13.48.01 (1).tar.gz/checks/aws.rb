
require "checks.rb"
require "actions_traces.rb"

class AWSRetryMode < Checks::ActionsTraces
  name "[AWS] Retry Mode"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/23"
  search_text "Amazon.Runtime.AmazonClientException: The initial request cannot be attempted because capacity could not be obtained."
  looking_for "retry problem"
end

class AWSUsingNTLM < Checks::ActionsTraces
  name "[AWS] Using NTLM"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/39"
  search_text "NTLM authentication requires the GSSAPI"
  looking_for "problems with NTLM"
end

$checks_to_run += [
  AWSRetryMode,
  AWSUsingNTLM,
]
