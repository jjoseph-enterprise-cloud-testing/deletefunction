#!/usr/bin/env ruby

# checks/instance.rb defines GitHub-specific checks that apply to
# a GitHub Enterprise Server instance. A GHES "instance" includes
# all the nodes present in a GHES HA setup or non-HA Cluster.

require "checks.rb"
require "helper.rb"

class MaintenanceMode < Checks::Base
  name "[System] Maintenance Mode"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/35"

  def run
    exit_code, _ = run_bash "ghe-maintenance -q 2>&1"
    unless exit_code == 1
      fail "The instance is in maintenance mode"
    else
      pass "The instance is not in maintenance mode"
    end
  end
end

$checks_to_run += [
  MaintenanceMode,
]
