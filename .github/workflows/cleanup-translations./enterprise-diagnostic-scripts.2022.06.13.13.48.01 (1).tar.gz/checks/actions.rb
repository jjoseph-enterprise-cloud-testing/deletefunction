#!/usr/bin/env ruby

require 'date'
require "checks.rb"

module Checks

  class ActionsDiagnostic < Base

    def check_actions
      # Define in child classes
    end

    def run
      return skipped("Slow Check") unless run_slow?

      exit_code, _ = run_bash "ghe-config --true app.actions.enabled 2>&1"
      return skipped("Actions is not enabled") unless exit_code == 0

      check_actions
    end
  end
end

class ActionsCheck < Checks::ActionsDiagnostic
  name "[Actions] Run ghe-actions-check"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/36"

  def check_actions
    exit_code, _ = run_bash "ghe-actions-check 2>&1"
    if  exit_code == 0
      pass "Passed basic checks"
    else
      fail "Failed basic Actions check"
    end
  end
end

class ActionsBlobCheck < Checks::ActionsDiagnostic
  name "[Actions] Check Blob Storage"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/112"

  def check_actions
    exit_code, _ = run_bash "ghe-actions-check -s blob 2>&1"
    if  exit_code == 0
      pass "Passed basic blob checks"
    else
      fail "Failed basic Actions blob check"
    end
  end
end

class ActionsServicesConnectivity < Checks::ActionsDiagnostic
  name "[Actions] Check Services Connectivity"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/25"

  def check_actions
    action_services.each do |source|
      action_services.each do |target|
        unless source == target
          exit_code, _ = run_bash "ghe-actions-check-connectivity --source #{source} --target #{target} 2>&1"
          return fail("#{source} could not communicate with #{target}") unless exit_code == 0
        end
      end
    end
    pass "All Actions Services can Communicate"
  end
end

class ValidateStarterWorkflows < Checks::ActionsDiagnostic
  name "[Actions] Validate Starter Workflows"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/51"

  def check_actions
    # Find the commit that the repo is on
    exit_code, commit_sha = run_bash "git --git-dir=/data/ghes-actions/current/repos/actions_starter-workflows/.git rev-parse HEAD 2>&1"
    return fail("Failed to find commit sha for /data/ghes-actions/current/repos/actions_starter-workflows") unless exit_code == 0

    commit_sha.strip!

    # Find the actions org, it is not always called actions
    exit_code, actions_org = run_bash "ghe-config app.actions.actions-org"
    return fail("Failed to find commit actions org name") unless exit_code == 0

    actions_org.strip!

    # now look if appliance knows about this commit
    ruby_command = "puts Repository.nwo('#{actions_org}/starter-workflows').commits.exist?('#{commit_sha}')"
    exit_code, text = run_bash " echo \"#{ruby_command}\" | github-env bin/safe-ruby -r ./config/environment 2>&1 "
    text.strip!
    if exit_code == 0 && "true".eql?(text)
      pass "The appliance has the correct commit"
    else
      fail "The appliance's starter-workflow is not up to date"
    end
  end
end

class ActionsStateMatchesDBs < Checks::ActionsDiagnostic
  name "[Actions] Check State Matches Database"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/60"

  def check_actions
    action_services.each do |service|
      database_name = configured_database_name(service)
      return error("Unable to retrieve database name") if database_name.nil?
      return error("Found unexpected character in database name #{database_name}") if database_name.include? "'"

      exists = database_exists?(database_name)
      return error("Database names couldn't be retrieved from MSSQL.") if exists.nil?

      log_detail "Found #{database_name}" if exists

      should_exist = database_should_exist?(service)
      return fail("MSSQL Database #{database_name} exists, but state file indicates it should not.") if exists && !should_exist
    end
    pass "All Actions States match DBs"
  end

  def configured_database_name(service)
    exit_code, database_info = run_bash "ghe-actions-console -s #{service} -c '(dir ConfigDbName).Value' 2>&1"
    return unless exit_code == 0

    matches = database_info.match /(?:.*)> (?<database_name>.*)/
    return if matches.nil?

    matches[:database_name]
  end

  def database_exists?(database_name)
    sql = "
    SET NOCOUNT ON;
    SELECT COUNT(1)
    FROM   sys.databases
    WHERE  name = '#{database_name}'"
    exit_code, database_info = run_bash "ghe-mssql-console -y -n -q \"#{sql}\" 2>&1"
    return unless exit_code == 0

    database_info.strip! == "1"
  end

  def database_should_exist?(service)
    exit_code, service_state = run_bash "cat /data/user/actions/states/#{service.downcase}_state 2>&1"

    # Service state files might not be available if the service isn't started yet.
    # In this case the database should also not exist.
    return false if exit_code != 0 || service_state.nil?

    ["complete", "created", "connected"].include?(service_state.strip!)
  end
end

class ActionsCheckReservedNames < Checks::ActionsDiagnostic
  name "[Actions] Check Reserved Users"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/62"

  def check_actions
    _, actions_org = run_bash %q( ghe-config app.actions.actions-org )
    actions_org.strip!
    if actions_org.empty?
      exit_code, result_count = run_bash %q( /usr/local/share/enterprise/github-mysql "SELECT count(*) FROM users WHERE users.login IN (\"actions\", \"github-actions\", \"github-actions-org\");" | tail -n1 )
      return fail("Could not access the the mysql table(s)") unless exit_code == 0
      return fail("All reserved actions org names are taken") if result_count.strip.to_i == 3
    else
      exit_code_user, result_user = run_bash %Q( /usr/local/share/enterprise/github-mysql "SELECT users.login FROM users WHERE users.login=\\"#{actions_org}\\" AND users.type=\\"Organization\\";" )
      return fail("Could not access the the mysql table(s)") unless exit_code_user == 0
      return fail("There is not an existing organization that corresponds to the configured actions org (app.actions.actions-org)") if result_user.empty?
    end
    pass "All reserved users are available"
  end
end

class ActionsCheckIntegrationConfiguration < Checks::ActionsDiagnostic
  name "[Actions] Check Bot Integration"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/62"

  def check_actions
    exit_code_bot, result_bot = run_bash %q( /usr/local/share/enterprise/github-mysql "SELECT users.login, users.id FROM users INNER JOIN integrations ON users.id=integrations.bot_id WHERE users.login=\"github-actions[bot]\" AND integrations.name=\"GitHub Actions\";" )

    return fail("Could not access the the mysql table(s)") unless exit_code_bot == 0
    return fail("There is no GitHub-Actions bot associated with a user") if result_bot.empty?

    pass "The GitHub-Actions bot integration is configured correctly"
  end
end

class ActionsIntegrationUserSuspended < Checks::ActionsDiagnostic
  name "[Actions] Check User Status"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/96"

  def check_actions
    # If actions integration user exists and is not suspended query will return row
    _, result_bot = run_bash %q( /usr/local/share/enterprise/github-mysql "SELECT login FROM users WHERE login = \"github-actions[bot]\" AND suspended_at IS NOT NULL;" )
    return fail("The GitHub-Actions user does not exist or is suspended") unless result_bot.empty?

    pass "The GitHub-Actions user is active"
  end
end

class ActionsProxyCheck < Checks::ActionsDiagnostic
  name "[Actions] Check Proxy"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/100"

  def check_actions
    _, proxy = run_bash "ghe-config core.http-proxy"
    proxy.strip!
    return skipped("No proxy found") if proxy.empty?

    _, no_proxy = run_bash "ghe-config core.http-noproxy"
    return fail("core.http-proxy is set, core.http-noproxy does not contain 'localhost,127.0.0.1,::1'") unless no_proxy.include? "localhost,127.0.0.1,::1"

    pass "The GitHub-Actions bot integration is configured correctly"
  end
end

class ActionsCheckPorts < Checks::Base
  name "[Actions] Check Open Ports"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/107"

  TCP_PROTOCOL = 6

  def run
    ports_to_check ={
      5000 => 'credz',
      5001 => 'launch-deployer'
    }

    port_list = ports_to_check.keys.join(',')
    query_str = "echo 'SELECT lp.port, ps.name FROM listening_ports AS lp INNER JOIN processes AS ps ON lp.pid = ps.pid
                 WHERE protocol = #{TCP_PROTOCOL} AND port in (#{port_list});' | osqueryi --list --noheader 2>&1"

    _, result = run_bash query_str

    unless result.empty?
      result.each_line do |line|
        line.strip!
        port, process = line.split("|")

        if (process != ports_to_check[port.to_i])
          return fail "Port '#{port}/tcp' is used by '#{process}' process"
        end
      end
    end

    pass "Passed ports checks"
  end
end

class ActionsPartitionsCheck < Checks::ActionsDiagnostic
  name "[Actions] Extra Database Partitions"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/109"

  def check_actions
    # Check if run from primary
    return skipped("This check runs only in primary") if is_replica

    result = true

    action_databases_prefixes.each do |db|
      db_configuration = "#{db}_configuration"
      sql = "SET NOCOUNT ON;
             SELECT name FROM sys.databases WHERE name LIKE '#{db}%' AND name != '#{db_configuration}' AND name NOT IN
             (SELECT REPLACE(DatabaseName, 'localhost;','') FROM [#{db_configuration}].[dbo].[tbl_Database]);"

      exit_code, partitions_info = run_bash "ghe-mssql-console -y -n -q \"#{sql}\" 2>&1"
      return error("Partition info couldn't be retrieved from MSSQL.") unless exit_code == 0

      unless partitions_info.empty?
        log_detail "Extra '#{db}' partitions: #{partitions_info}"
        result = false
      end
    end

    return fail("Not referenced database partitions have been found") unless result
    pass "All database partitions are valid"
  end
end

class ActionsReplicaPartitionCheck < Checks::ActionsDiagnostic
  name "[Actions] Multiple database partitions and outdated ghe-repl-status-mssql"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/110"

  def check_actions
    # Check if run from replica
    return skipped("This check runs only in replica") unless is_replica

    # Check GHES version, ghe-repl-status-mssql fixed in 3.1.9
    return skipped "Current version has ghe-repl-status-mssql patched" if current_release_is('>= 3.1.9')

    action_databases_prefixes.each do |db|
      sql = "SET NOCOUNT ON;
             SELECT Count(*) FROM sys.databases WHERE name LIKE '#{db}%' AND name != '#{db}_configuration';"

      exit_code, partitions_info = run_bash "ghe-mssql-console -y -n -q \"#{sql}\" 2>&1"
      return error("Partition info couldn't be retrieved from MSSQL.") unless exit_code == 0

      count = partitions_info.to_i
      if count > 1
        return fail "Multiple '#{db}' partitions have been found"
      end
    end

    pass "Replica database partition check passed"
  end
end

class ActionsReplicationCertificateCheck < Checks::ActionsDiagnostic
  name "[Actions] Database Replication Certificate"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/131"

  SQL_ERROR = "MSSQL couldn't be queried for replication certificate."

  def check_actions
    certificate_sql =
      "SET NOCOUNT ON;
      SELECT start_date, '|', expiry_date, '|',
        CASE
          WHEN expiry_date < GETUTCDATE() THEN '1' ELSE '0'
        END AS is_expired
      FROM   master.sys.certificates
      WHERE  name = 'dbm_certificate';"
    exit_code, certificate_info = run_bash "ghe-mssql-console -y -n -q \"#{certificate_sql}\" 2>&1"

    return error(SQL_ERROR) if exit_code != 0
    return skipped "No replication certificate found" if certificate_info.empty?

    start_date, expiry_date, is_expired = certificate_info.split('|')
    return error(SQL_ERROR) if [start_date, expiry_date, is_expired].any?(:nil?)

    start_date = DateTime.parse(start_date)
    expiry_date = DateTime.parse(expiry_date)
    is_expired = is_expired.to_i > 0

    if is_expired
      return fail "Replication certificate is expired (#{start_date.strftime("%F")} -> #{expiry_date.strftime("%F")})"
    end

    pass "Database replication certificate is not expired"
  end
end

class ActionsAvailabilityGroupCheck < Checks::ActionsDiagnostic
  name "[Actions] Availability Group Configuration"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/111"

  def check_actions
    sql = "SET NOCOUNT ON;
           SELECT Count(*) FROM sys.availability_groups WHERE name = 'ha'"

    exit_code, availability_group = run_bash "ghe-mssql-console -y -n -q \"#{sql}\" 2>&1"
    return error("Availabilty group couldn't be retrieved from MSSQL.") unless exit_code == 0

    count = availability_group.to_i
    if count > 0
      # If availability group is set check configuration
      return fail("File '/etc/github/cluster' is missing") unless File.exist?("/etc/github/cluster")

      cluster_name = File.read("/etc/github/cluster")
      _, hostname = run_bash "hostname 2>&1"

      cluster_name.strip!
      hostname.strip!
      return fail("Node hostname mismatch") unless (cluster_name == hostname)

      return fail("File '/etc/github/repl-state' is missing") unless File.exist?("/etc/github/repl-state")
    end

    pass "Availability group checks passed"
  end
end

class ActionsSetupFailuresCheck < Checks::ActionsDiagnostic
  name "[Actions] Check for setup-failures-detected flag"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/5"

  def check_actions
    exit_code, _ = run_bash "ghe-config --true app.actions.setup-failures-detected 2>&1"
    if  exit_code == 0
      fail "The app.actions.setup-failures-detected is set, indicating issues setting up actions org and repos"
    else
      pass "The app.actions.setup-failures-detected flag is not set"
    end
  end
end

class ActionsUpdatesDisabledCheck < Checks::ActionsDiagnostic
  name "[Actions] Check for updates-disabled flag"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/136"

  def check_actions
    exit_code, _ = run_bash "ghe-config --true app.actions.updates-disabled 2>&1"
    if  exit_code == 0
      fail "The app.actions.updates-disabled is set, indicating Actions updates are currently getting skipped"
    else
      pass "The app.actions.updates-disabled flag is not set"
    end
  end
end

class ActionsTLSEnabled < Checks::ActionsDiagnostic
  name "[Actions] Check that TLS is enabled"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/144"

  def check_actions
    exit_code, _ = run_bash "ghe-config --true github-ssl.enabled 2>&1"
    if exit_code == 0
      pass "The github-ssl.enabled flag is set to true"
    else
      fail "The github-ssl.enabled flag is set to false, indicating that TLS is not enabled"
    end
  end
end

$checks_to_run += [
  ActionsCheck,
  ActionsBlobCheck,
  ActionsServicesConnectivity,
  ValidateStarterWorkflows,
  ActionsStateMatchesDBs,
  ActionsCheckReservedNames,
  ActionsCheckIntegrationConfiguration,
  ActionsIntegrationUserSuspended,
  ActionsProxyCheck,
  ActionsCheckPorts,
  ActionsPartitionsCheck,
  ActionsReplicaPartitionCheck,
  ActionsReplicationCertificateCheck,
  ActionsAvailabilityGroupCheck,
  ActionsSetupFailuresCheck,
  ActionsUpdatesDisabledCheck,
  ActionsTLSEnabled
]
