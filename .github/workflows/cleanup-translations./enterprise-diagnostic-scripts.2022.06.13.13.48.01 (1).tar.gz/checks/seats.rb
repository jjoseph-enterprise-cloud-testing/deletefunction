#!/usr/bin/env ruby

require "checks.rb"
require "helper.rb"

class SeatLimitations < Checks::Base
  name "[Licences] Seat Limitations"
  issue_url "https://github.com/github/enterprise-diagnostic-scripts/issues/5"

  def run
    log_detail "Licence seats       #{license_seats.to_s.rjust(6)}"
    log_detail "Total users         #{total_users.to_s.rjust(6)}"
    log_detail "Suspended users     #{suspended_users.to_s.rjust(6)}"
    log_detail "Active Seats        #{active_seats.to_s.rjust(6)} (total - suspended)"
    log_detail "Unlimited Seats     #{unlimited_seats.to_s}"

    if license_seats == 0 and unlimited_seats == "true"
      pass "The instance has an unlimited seat license"
    elsif active_seats >= license_seats
      fail "The number of active users is at or above license seat limit (#{active_seats}/#{license_seats})"
    else
      pass "The instance is within all seat limits"
    end
  end
end

$checks_to_run += [
  SeatLimitations,
]
