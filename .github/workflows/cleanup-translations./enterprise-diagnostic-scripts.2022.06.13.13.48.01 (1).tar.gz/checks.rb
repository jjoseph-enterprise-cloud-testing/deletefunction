#!/usr/bin/env ruby

require "helper.rb"
require 'forwardable'

module Checks
  class Base
    extend Forwardable
    attr_accessor :status, :message, :action_services, :action_databases_prefixes

    def initialize(helper, options)
      @helper = helper
      @run_slow = options[:run_slow]
      exit_code, services = run_bash "/bin/bash -c '. /usr/local/share/enterprise/ghe-actions-lib; action-services'"
      raise("Fail to get action services") unless exit_code == 0
      @action_services = services.split
      exit_code, databases = run_bash "/bin/bash -c '. /usr/local/share/enterprise/ghe-actions-lib; actions-db-prefixes'"
      raise("Fail to get action databases prefixes") unless exit_code == 0
      @action_databases_prefixes = databases.split
    end

    def_delegators :@helper, :log, :log_detail, :run_bash, :run_bash_silent, :running_as_root?, :license_seats, :unlimited_seats, :total_users,
                   :suspended_users, :active_seats, :is_replica, :current_release_is

    # Setters
    def self.name(name)
      @name = name
    end

    def self.issue_url(issue_url)
      @issue_url = issue_url
    end

    # Getters
    def name
      self.class.instance_variable_get("@name")
    end

    def issue_url
      self.class.instance_variable_get("@issue_url")
    end

    def run!
      log_detail "-"*100
      log_detail "Starting #{name} (Class: #{self.class})..."
      begin
        run
      rescue => e
        log_detail e.to_s
        fail e.to_s
      end

      log "#{status} #{name} - #{message}"
      log_detail "Finished #{name} (Class: #{self.class})"
    end

    def run
      # Define in child classes
    end

    def set_status(msg)
      @status = msg
    end

    # Indicates that the check was successful.
    def pass(msg)
      self.status = "✅"
      self.message = msg
    end

    # Indicates the specific problem the check was looking for was found, and customer should follow the steps in the issue to get unblocked.
    def fail(msg)
      self.status = "❗️"
      self.message = "#{msg} - see #{issue_url}"
    end

    # Indicates that the check could not be run because
    # elevated privileges are needed.
    def needs_root
      self.status = "❓"
      self.message = "Please run the script as root with 'sudo'"
    end

    # Indicactes that the check was not performed because
    # it's not applicable to the current appliance.
    def skipped(msg)
      self.status = "🟡"
      self.message = "skipped: #{msg}"
    end

    # Indicates that the check could not be performed because
    # we ran into unexpected errors.
    def error(msg)
      # NOTE: For now we display this is in a similar way to `skipped`.
      self.status = "🟡"
      self.message = "Couldn't perform check: #{msg}"
    end

    def run_slow?
        @run_slow
    end
  end
end
