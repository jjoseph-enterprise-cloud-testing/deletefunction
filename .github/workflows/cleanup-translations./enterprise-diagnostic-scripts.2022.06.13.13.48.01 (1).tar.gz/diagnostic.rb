#!/usr/bin/env ruby
require 'optparse'

local_dir = File.expand_path('../', __FILE__)
$LOAD_PATH.unshift(local_dir)

$checks_to_run = Array.new()
require "checks/actions.rb"
require "checks/aws.rb"
require "checks/instance.rb"
require "checks/mssql.rb"
require "checks/seats.rb"
require "checks/secrets.rb"
require "checks/system.rb"
require "checks/nomad.rb"

options = {}
options[:run_slow] = true
options[:active_seats] = nil

OptionParser.new do |opts|
  opts.banner = "Usage: ./diagnostic.rb [options]"

  opts.on_tail("-h", "--help", "Prints this help") do
    warn opts
    exit 2
  end

  opts.on("-t", "--test TestClassName", "Run a specific test") do |test_name|
    options[:test_name] = test_name

    begin
      options[:test_class] = Object.const_get(test_name)
    rescue NameError
      warn "#{test_name} does not match an available test"
      exit 2
    end
  end

  opts.on("-s", "--skip-slow", "Skip all tests deemed to be slow") do
    options[:run_slow] = false
  end

  opts.on("-a", "--active-seats n", "Fake the number of active seats to be n") do |seats|
    options[:active_seats] = seats.to_i
  end

  opts.on("-r", "--enterprise-release <semver>", "Fake the release version of GHES to be <semver>") do |version|
    options[:enterprise_release] = Gem::Version.create(version)
  end
end.parse!

$checks_to_run = [options[:test_class]] if options[:test_class]

log_file = File.open("full_details.log", "w")
helper = Helper.new(log_file, options)
helper.log_version
helper.log("If your environment is configured for High Availability, please collect the result from the primary and all replicas.")
helper.log("Please share the following output and the contents of the file named full_details.log with support.")

$checks_to_run.each do |check_class|
  check_class.new(helper, options).run!
end

log_file.close
